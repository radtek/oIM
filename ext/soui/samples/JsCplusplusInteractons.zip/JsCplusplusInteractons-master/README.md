# JsCplusplusInteractons
实现基于 wke 的浏览器内核 demo 中，js 和 c++ 的互调交互

详细介绍在博客里已经有了，这里不再赘述

[基于 wke 的浏览器：如何实现 js 和 c++ 的互相调用](http://blog.csdn.net/u012814856/article/details/70312494)

以下是效果图：

C++ 调用 js

![C++ 调用 js](https://github.com/wangying2016/JsCplusplusInteractons/raw/master/picture/1.jpg)


js 调用 C++

![js 调用 C++](https://github.com/wangying2016/JsCplusplusInteractons/raw/master/picture/2.jpg)
